import pandas as pd, json
O="/mnt/user-data/outputs/"
t=pd.read_csv(O+"transactions.csv"); w=pd.read_csv(O+"workflow_tasks.csv"); c=pd.read_csv(O+"customers.csv"); e=pd.read_csv(O+"employees.csv"); ov=pd.read_csv(O+"business_overview_monthly.csv")
log={}
for df in (t,w,c,e):
    for col in df.select_dtypes("object"): df[col]=df[col].str.strip()
t["date"]=pd.to_datetime(t["date"]); w["created_date"]=pd.to_datetime(w["created_date"])
log["dup_ids"]=int(t.transaction_id.duplicated().sum()+w.task_id.duplicated().sum()+e.employee_id.duplicated().sum())
log["month_mismatch"]=int((t.date.dt.strftime("%Y-%m")!=t.month).sum())
log["bad_amounts"]=int((t.amount_ngn<=0).sum())
log["not_completed_excluded"]=int((t.status!="Completed").sum())
log["rev_without_customer"]=int(((t.transaction_type=="Revenue")&t.counterparty_id.isna()&(t.category!="Grant Income")).sum())
log["orphan_task_owner"]=int((~w.assigned_to.isin(e.employee_id)).sum())
t["sig"]=t.subsidiary.str.replace("Yelwa ","").str.replace(" Limited","")
ok=t[t.status=="Completed"].copy()
M=sorted(ok.month.unique()); S=["Holdings HQ","Yelwa Agro Limited","Yelwa Fintech Limited","Yelwa Logistics Limited","Yelwa Properties Limited","Yelwa Tech Limited"]
k=lambda x:int(round(x/1000))
chk=0; R=[]
for i,m in enumerate(M):
  for j,s in enumerate(S):
    x=ok[(ok.month==m)&(ok.subsidiary==s)]; rv=x[x.transaction_type=="Revenue"].amount_ngn.sum(); ex=x[x.transaction_type=="Expense"]
    pay=ex[ex.category=="Payroll"].amount_ngn.sum(); tax=ex[ex.category=="Taxes & Levies"].amount_ngn.sum(); opx=ex.amount_ngn.sum()-pay-tax
    hc=int(ov[(ov.month==m)&(ov.subsidiary==s)].headcount.iloc[0]); chk+=abs(rv-ov[(ov.month==m)&(ov.subsidiary==s)].revenue_ngn.iloc[0])
    R.append([i,j,k(rv),k(pay),k(opx),k(tax),hc])
log["overview_rev_diff"]=int(chk)
w["mi"]=w.created_date.dt.strftime("%Y-%m").map({m:i for i,m in enumerate(M)}); w["st"]=w.status.map({"Completed":0,"Overdue":1}).fillna(2).astype(int)
T=[[S.index(a),int(b),int(c_),int(n)] for (a,b,c_),n in w.groupby(["subsidiary","mi","st"]).size().items()]
rc=ok[(ok.transaction_type=="Revenue")&ok.counterparty_id.notna()].groupby(["counterparty_name","month"]).amount_ngn.sum().unstack(fill_value=0).reindex(columns=M,fill_value=0)
top=rc.sum(axis=1).nlargest(12).index; sm=dict(zip(c.customer_name,c.primary_subsidiary))
C=[[n,S.index(sm[n]),[k(v) for v in rc.loc[n]]] for n in top]
data=json.dumps({"m":[pd.Timestamp(m+"-01").strftime("%b %y") for m in M],"s":[s.replace("Yelwa ","").replace(" Limited","") for s in S],"r":R,"t":T,"c":C},separators=(",",":"))
html=open("tpl.html").read().replace("__DATA__",data)
open(O+"yelwa_dashboard.html","w").write(html); print(log,len(html))
